#%% Exercise 1


import matplotlib.pylab as plt
import numpy as np

#X=np.random.randn(100,3)
#
#y=X.dot(np.array([1,2,3]))+np.random.randn(100)

class OLS(object):
    
    def __init__(self, y, X):
        self.y = y
        self.X = X
        self.beta = self.beta()
        XX = np.linalg.inv(np.transpose(X) @ X)
        self.XX = XX
        self.std = self.std(self.beta)
        self.V = self.V(self.beta, self.XX,self.std)
        self.predictY = self.predictY(self.beta)
        self.predictV = self.predictV(self.std, self.beta, self.XX)
          
    def beta(self):
        XX = np.linalg.inv(np.transpose(X) @ X)
        beta = XX @ np.transpose(X) @ y 
        return beta
    
    def std(self,beta):
        std=(1 / (len(X) - len(beta))) * np.transpose((y - X @ beta)) @ (y - X @ beta)
        return std        

    def V(self, beta, XX,std):
        V = std * XX
        return V

    def predictV(self, std, beta, XX):
        V = std * (1+ X @ XX @ np.transpose(X) )
        return(V)

    def predict(self, x_predict):
        self.x_predict = x_predict
        y_predict = x_predict * self.beta
        V_predict = self.std * (1 + np.transpose(x_predict) @ self.XX @ x_predict)
        return(y_predict, V_predict)
    
#%%
#Exercise 2

#import matplotlib
import matplotlib.pyplot as plt
import numpy as np 

Beta = np.random.uniform( low = 0, high = 1, size = (10) )

Oshibki = 10 * np.random.randn(200)
X = np.random.uniform( low = -5, high = 5, size = (200))

def factorial(N):
    if (N == 0):
        return(1)
    return (N * factorial(N-1))

Number = 10
y = 0
X = sorted(X)

for i in range(Number):
    y += Beta[i] * np.power(X, i) / factorial(i)

y = y + Oshibki

plt.xlim(-5, 5)
plt.ylim(-20 , 100)
plt.scatter(X, y, marker = 'o', label = "Data")
plt.xlabel("$x_i$")
plt.ylabel('$y_i$')
#plt.show()

X_rem = X

X1 = np.vstack((X, np.power(X,2)))
X2 = np.vstack((np.power(X,3), np.power(X,4)))
X = np.vstack((X1, X2))
X = np.transpose(X)

model = OLS(y, X)
Y =  X[:,0] * model.beta[0]

plt.plot(X[:,0], Y, label = "K = 1")

Y =  X[:,0] * model.beta[0] + X[:,1] * model.beta[1]

plt.plot(X[:,0], Y, label = "K = 2")

Y =  X[:,0] * model.beta[0] + X[:,1] * model.beta[1] + X[:,2] * model.beta[2]

plt.plot(X[:,0], Y, label = "K = 3")

Y =  X[:,0] * model.beta[0] + X[:,1] * model.beta[1] + X[:,2] * model.beta[2] + X[:,3] * model.beta[3]

plt.plot(X[:,0], Y, label = "K = 4")
plt.legend(loc='best') 


upper = Y + model.std * 1.64 / np.sqrt(200)
lower = Y - model.std * 1.64 / np.sqrt(200)
#plt.plot(plot_k4[ 0, :], lowerbound, label='Data')
#plt.plot(plot_k4[ 0, :], upperbound, label='Data')
plt.fill_between(X[:,0], upper, lower, alpha = 0.5 , facecolor='gray', interpolate=True)
plt.savefig('demo.pdf', transparent=True)

plt.show()



#%% Exercise 3
import scipy
from scipy import stats

normal_n = np.random.randn(100, 100)

print(normal_n)

mean = normal_n.mean(axis = 0)
std = normal_n.std(axis = 0)

#print (mean)
#print(std)
#class huina(object):
#    def metod_huetod(L):
#        print(L)

Z_crit = scipy.stats.t.ppf(0.9, len(normal_n))

Dov_upper = mean + Z_crit * std / (np.sqrt(len(normal_n)))
Dov_down = mean - Z_crit * std / (np.sqrt(len(normal_n)))

Flag = []
Counter = 0

for i in range(len(Dov_upper)):
    if np.any((0 < Dov_upper[i]) and (0 > Dov_down[i])):
        Flag.append(True)
        Counter += 1
    else:
        Flag.append(False)

for i in range(len(Flag)):
    print(Flag[i], ' ')

print(Counter)    
#print(Flag)

#%% Exercise 4
import pandas as pd
import csv

df1 = pd.read_csv('untitled.csv', 'goalies-2014-2016', delimiter = ';', names = ['n', 'player', 'season', 'team', 'position', 'games_played', 'games_started', 'wins', 'loses', 'overtime_losses', 'shots_against', 'saves', 'goals_against', 'save_percentage','goal_against_average', 'time_on_ice', 'shut_outs', 'goals', 'assists', 'points', 'penalty_minutes'], skiprows = 1)

# Первый номер

head = df1.head(5)

print(head[['n', 'player', 'season', 'team', 'position', 'games_played']])

Otklonenie = []

# Второй номер
#%%
for i in range(len(df1.n)):
    Otklonenie.append(abs( df1.saves[i] / df1.shots_against[i] - df1.save_percentage[i])) 

max(Otklonenie)

#%%
# Третий номер

print('games_played', '      ', df1.games_played.mean())
print('goals_against', '     ',df1.goals_against.mean())
print('save_percentage','   ',df1.save_percentage.mean())
print()
print('games_played', '      ', df1.games_played.std())
print('goals_against', '     ',df1.goals_against.std())
print('save_percentage','   ',df1.save_percentage.std())

#%%
# Четвертый номер

df2 = df1[(df1['season'] == '2016-17') & (df1['games_played'] > 40)]
k = df2['save_percentage'].idxmax()
K = df2[df2['n'] == k + 1]
K[['n', 'player', 'save_percentage']]

#%%
# Пятый номер

df2 = df1[df1['season'] == '2016-17']
k1 = df2['saves'].idxmax()

df2 = df1[df1['season'] == '2015-16']
k2 = df2['saves'].idxmax()

df2 = df1[df1['season'] == '2014-15']
k3 = df2['saves'].idxmax()

df1.iloc[[k1, k2, k3]][['season','player', 'saves']]

#%%
# Шестой номер

df16 = df1[(df1['season'] == '2016-17') & (df1['wins'] >= 30)]

df15 = df1[(df1['season'] == '2015-16') & (df1['wins'] >= 30)]

df14 = df1[(df1['season'] == '2014-15') & (df1['wins'] >= 30)]

DF = df16.append([df15, df14])

names = {}

for i in range(len(DF)):
    if DF.iloc[i]['player'] in names:
#        print('A')     
        name = DF.iloc[i]['player']
        names[name] += 1
    else:
        name = DF.iloc[i]['player']
        names[name] = 1

df22 = pd.DataFrame(columns = df1.columns)

for i in names:
    if names[i] == 3:
        df22 = df22.append(df1[df1['player'] == i])

print(df22[['player', 'season', 'wins']])