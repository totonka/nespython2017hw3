# -*- coding: utf-8 -*-
"""
Created on Sun Feb  4 18:17:35 2018

@author: Ruslan Safiullin
"""

#%% Exercise 1


import matplotlib.pylab as plt
import numpy as np

X=np.random.randn(100,3)

y=X.dot(np.array([1,2,3]))+np.random.randn(100)

class OLS(object):
    
    def __init__(self, y, X):
            
        self.y=y
        self.X=X
        self.beta = self.beta()
        XX=np.linalg.inv(np.transpose(self.X) @ self.X)
        self.XX=XX
        self.std=self.std(self.beta)
        self.V = self.V(self.beta, self.XX,self.std)
        self.predictY = self.predictY(self.beta)
        self.predictV = self.predictV(self.std,self.beta, self.XX)
        
    def beta(self):
       #(X'X)^-1   
        XX=np.linalg.inv(np.transpose(self.X) @ self.X)
        beta=XX @ np.transpose(self.X) @ self.y 
        return beta
    def std(self,beta):
        std=(1/(len(self.X)-len(beta)))*np.transpose((self.y-self.X @ beta)) @ (self.y-self.X @ beta)
        return std        

    def V(self,beta,XX,std):
        V=self.std*XX
        return V

    def predictY(self,beta):
        y_estim=np.sum(self.X*self.beta, axis=1)
        return y_estim
    
    def predictV(self, std,beta, XX):
        V_estim=self.std*(1 + self.X @ XX @ np.transpose(self.X))
        return(V_estim)
    
    def predict(self, t):
        self.t=t
        y=np.sum(t*self.beta)
        V=self.std*(1 + np.transpose(t) @ self.XX @ t )
        return(y,V)

model=OLS(y,X)

model.predict(np.array([1,0,1]))

#%%
#Exercise 2
#
#
#


import numpy as np
from scipy import stats

class OLS(object):
    
    def __init__(self, y, X):
            
        self.y=y
        self.X=X
        self.beta = self.beta()
        XX=np.linalg.inv(np.transpose(self.X) @ self.X)
        self.XX=XX
        self.std=self.std(self.beta)
        self.V = self.V(self.beta, self.XX,self.std)
        self.predictY = self.predictY(self.beta)
        self.predictV = self.predictV(self.std,self.beta, self.XX)
        
    def beta(self):
       #(X'X)^-1   
        XX=np.linalg.inv(np.transpose(self.X) @ self.X)
        beta=XX @ np.transpose(self.X) @ self.y 
        return beta
    def std(self,beta):
        std=(1/(len(self.X)-len(beta)))*np.transpose((self.y-self.X @ beta)) @ (self.y-self.X @ beta)
        return std        

    def V(self,beta,XX,std):
        V=self.std*XX
        return V

    def predictY(self,beta):
        y_estim=np.sum(self.X*self.beta, axis=1)
        return y_estim
    
    def predictV(self, std,beta, XX):
        V_estim=self.std*(1 + self.X @ XX @ np.transpose(self.X))
        return(V_estim)
    
    def predict(self, t):
        self.t=t
        y=np.sum(t*self.beta)
        V=self.std*(1 + np.transpose(t) @ self.XX @ t )
        return(y,V)

betas= np.random.uniform(low=0, high=1, size=(10,))

u=10*np.random.randn(200)  #sigma=sqrt100
X=np.random.uniform(low=-5, high=5, size=(200,))
def factorial(N):
    if (N==0):
        return(1)
    return (N*factorial(N-1))

##generating y
p=10
y=0
for k in range(p):
    y+=betas[k]*np.power(X,k)/factorial(k)
##сгерерировали Y и прибавили ошибку
y=y+u    

#GEnerating array with X powered   создаем матрицу регррессоров (в степени k)
p2=2
for k in range(p2):
    X=np.vstack((X,X))
    
for i in range(len(X)-1):
    X[i+1,:]=X[i,:]*X[i,:]
    
    
X=np.swapaxes(X,0,1)



X1=np.array(X[:,0])
X1=X1[:,np.newaxis]
model1=OLS(y,X1)

X2=np.array(X[:,:2])   
model2=OLS(y,X2)
X3=np.array(X[:,:3])
model3=OLS(y,X3)
X4=np.array(X[:,:4])
model4=OLS(y,X4)

##INDIAN CODE
###test with plot
plt.xlim([-5,5])
plt.plot(X[:, 0], y, 'o', label='Data')
###
plt.plot(X[:, 0], model1.predictY, label='K1')
##
line=model2.predictY
plot_k4=np.vstack((X[:, 0],line))
plot_k4=plot_k4[:, np.argsort( plot_k4[0] ) ]
plt.plot(plot_k4[ 0, :], plot_k4[1,:] , label='K2')
###
line=model3.predictY
plot_k4=np.vstack((X[:, 0],line))
plot_k4=plot_k4[:, np.argsort( plot_k4[0] ) ]
plt.plot(plot_k4[ 0, :], plot_k4[1,:] , label='K3')
####
line=model4.predictY
plot_k4=np.vstack((X[:, 0],line))
plot_k4=plot_k4[:, np.argsort( plot_k4[0] ) ]
plt.plot(plot_k4[ 0, :], plot_k4[1,:], label='K4')
#
#
z_crit=stats.t.ppf(0.9,len(X))
#доверительный интервал для 90%   y+-z_crit*stderror/sqrt(n)
upperbound=plot_k4[1,:]+model2.std*z_crit/np.sqrt(len(X))
lowerbound=plot_k4[1,:]-model2.std*z_crit/np.sqrt(len(X))
#plt.plot(plot_k4[ 0, :], lowerbound, label='Data')
#plt.plot(plot_k4[ 0, :], upperbound, label='Data')
#plt.fill_between(plot_k4[0,:], upperbound, lowerbound, facecolor='gray', interpolate=True)
plt.xlabel('$x_i$')
plt.ylabel('$y_i$') 
plt.legend(loc='best')
plt.savefig('graphs.pdf', transparent=True)
plt.show()


plt.fill_between(plot_k4[0,:], upperbound, lowerbound, facecolor='lightgray', interpolate=True)
plt.plot(X[:, 0], y, 'o', label='Data')
plt.plot(plot_k4[ 0, :], plot_k4[1,:], label='K4')
plt.xlabel('$x_i$')
plt.ylabel('$y_i$') 
plt.legend(loc='best')
plt.savefig('area.pdf', transparent=True)
plt.show()


#%%
#Exercise 3

import matplotlib.pylab as plt
import numpy as np
from scipy import stats



mx=np.random.randn(100,100)

mean=mx.mean(axis=0)
std=mx.std(axis=0)

z_crit=stats.t.ppf(0.9,len(mx))

upperbound=mean+std*z_crit/np.sqrt(len(mean))
lowerbound=mean-std*z_crit/np.sqrt(len(mean))

interv=np.vstack((lowerbound,upperbound))
#counting if 0 out of bounds
bools=[]
counter=0
for i in range(len(upperbound)):
    k=np.any( 0<upperbound[i] and 0>lowerbound[i], axis=0)
    bools.append(k)
    if k:
        counter+=1
        
print(bools)
print(counter)        
        
#by rows now  
mean_r=mx.mean(axis=1)
std_r=mx.std(axis=1)   
upperbound_r=mean_r+std_r*z_crit/np.sqrt(len(mean))
lowerbound_r=mean_r-std_r*z_crit/np.sqrt(len(mean))

bools_r=[]
counter_r=0
for i in range(len(upperbound_r)):
    k=np.any( 0<upperbound_r[i] and 0>lowerbound_r[i], axis=0)
    bools_r.append(k)
    if k:
        counter_r+=1
     
print(bools_r)
print(counter_r)        
               
        
#%% Exercise 4

import matplotlib.pylab as plt
import numpy as np
import pandas as pd


path='goalies-2014-2016.csv'

game = pd.read_csv(path, 'goalies-2014-2016', delimiter=';')

#1
game.head(5)
#2
#%% 
disp=[]
for i in range(len(game.n)): 
   disp.append(abs( game.saves[i] / game.shots_against[i] - game.save_percentage[i])) 

print(max(disp))
#3
#%% 
print("Mean")
print("games_played: %s " % (game.games_played.mean()))
print("goals_against: %s " % (game.goals_against.mean()))
print("save_percentage: %s " % (game.save_percentage.mean()))

print("STD")
print("games_played: %s " % (game.games_played.std()))
print("goals_against: %s " % (game.goals_against.std()))
print("save_percentage: %s " % (game.save_percentage.std()))


#%%
#4
data_games = game[(game['games_played'] > 40) & (game['season'] == '2016-17')] 
index_row_game = np.argmax(data_games['save_percentage'], axis=1)
name=data_games['player'][index_row_game]
save=game['save_percentage'][index_row_game]
#print (" index %s \n name %s \n save_percentage  %s" % (index_row_game,name,save))
game.iloc[[index_row_game]][['player','save_percentage']]


#%%
##5
data_games = game[(game['season'] == '2016-17')] 
data1=data_games['saves'].idxmax()
data_games2 = game[(game['season'] == '2015-16')] 
data2=data_games2['saves'].idxmax()
data_games3 = game[(game['season'] == '2014-15')] 
data3=data_games3['saves'].idxmax()

game.iloc[[data1,data2,data3]][['season','player','saves']]##
#print(data_games[['season','player','saves']].iloc[data1])


#%%
##6 

data_games = game[(game['wins'] > 30) & (game['season'] == '2016-17')]
data_games2 = game[(game['wins'] > 30) & (game['season'] == '2015-16')]
data_games3 = game[(game['wins'] > 30) & (game['season'] == '2014-15')]

data_total = data_games.append([data_games2, data_games3])

Imena = {}

for i in range(len(data_total)):
    if data_total.iloc[i]['player'] in Imena:
        name = data_total.iloc[i]['player']
        Imena[name] += 1
    else:
        name = data_total.iloc[i]['player']
        Imena[name] = 1
        
data_final = pd.DataFrame(columns = data_total.columns)

for i in Imena:
    if Imena[i] == 3:
        data_final = data_final.append(data_total[data_total['player'] == i])
        
print(data_final[['player', 'season', 'wins']])